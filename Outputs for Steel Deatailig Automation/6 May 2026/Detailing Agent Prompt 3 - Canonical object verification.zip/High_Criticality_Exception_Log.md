# HIGH-CRITICALITY EXCEPTION LOG
## Canonical_PEB_Object_Master Verification
## C163-027 Saswad Industrial Shed & Crane Building

**Report Date:** 6-MAY-2026  
**Exception Count:** 4  
**Blocking Exceptions:** 2  
**Timeline:** Issues 1-2 urgent (ASAP); Issues 3-4 high (by 15-JUN)

---

## EXECUTIVE SUMMARY

| Category | Count | Severity | Blocking | Impact |
|----------|-------|----------|----------|--------|
| **Critical (Block GA)** | 2 | CRITICAL | YES | ✗ GA Blocked |
| **High (Ambiguous Mapping)** | 2 | HIGH | PARTIAL | ⚠ Anchor Bolt Plan clarity |
| **TOTAL** | **4** | | **2 Blocking** | |

---

## CRITICAL EXCEPTIONS

### E-COBJ-001: Missing Primary Member Coordinates (CRITICAL)

**ID:** E-COBJ-001  
**Title:** Missing coordinates for high-criticality primary members  
**Category:** Master Data - Geometry  
**Severity:** **CRITICAL**  
**Blocking:** **YES - Blocks GA Production**  
**Status:** OPEN  
**Owner:** Design Authority (MBS data owner)

---

#### Issue Details

**Affected Objects:**
1. OBJ-RF-COL-001 (Primary Column)
2. OBJ-RF-COL-002 (Primary Column)
3. OBJ-RF-RAF-001 (Primary Rafter)

**Missing Fields:**
- Start_X, Start_Y, Start_Z (start point coordinates)
- End_X, End_Y, End_Z (end point coordinates)

**Current Status:**
- All 3 objects have qualitative location data (Grid_Line, Frame_No, Bay_No)
- All 3 objects have quantitative coordinates set to NULL/NaN
- Objects marked FROZEN in design status but coordinates missing in master

**Impact on Detailing:**

| Impact Area | Severity | Details |
|---|---|---|
| **GA Drawing Production** | CRITICAL | Cannot draw member centerlines; no Start/End points for line geometry |
| **3D Visualization** | CRITICAL | Cannot render 3D model without coordinates |
| **Interference Detection** | CRITICAL | Cannot check for member overlap/clash |
| **Fabrication Drawing** | CRITICAL | Member location undefined; fabricator cannot position member in building |
| **Erection Sequence** | CRITICAL | Cannot plan sequential assembly without member locations |
| **Bill of Materials** | MEDIUM | BOM possible from section data; but spatial references lost |

**Root Cause:** Canonical_PEB_Object_Master spreadsheet populated with design metadata (type, section, criticality) but 3D geometric coordinates not extracted/populated from MBS model.

**Expected Data Source:**
- MBS model export (member node coordinates)
- OR 3_Grid_Geometry sheet in Design_to_Detailing_Handoff.xlsx (building grid lines & column heights)
- OR frozen design assumptions document (span, eave height, roof slope → derive coordinates mathematically)

---

#### Resolution Path

**Step 1: Identify Coordinate Source** (Immediate)
- Check MBS model for member centroid coordinates
- OR extract from 3_Grid_Geometry & frozen dimensions
- Owner: Design Authority (MBS administrator)
- Timeline: **Same day** (no approval needed; data extraction only)

**Step 2: Populate Canonical Master** (Within 24 hours)
- Extract coordinates for 3 primary members
- Populate Start_X/Y/Z, End_X/Y/Z fields
- Validate against design freeze (no changes to member location)
- Owner: Design Authority
- Timeline: **By EOD 31-MAY-2026** (before GA start 1-JUN)

**Step 3: Validate & Cross-Check** (Within 24 hours)
- Verify coordinates consistent with frozen assumptions
- Check for consistency with grid geometry
- Validate member lengths match design lengths
- Owner: Design Authority (QA)
- Timeline: **By EOD 31-MAY-2026**

**Step 4: Notify Detailing Team** (Same day as completion)
- Release updated Canonical_PEB_Object_Master.xlsx
- Confirm GA production can begin
- Owner: Design Authority
- Timeline: **By 1-JUN-2026 morning**

**Workaround if Timeline Slips:**
- Detailing team can extract coordinates directly from MBS model
- Requires MBS model access & training
- Not recommended (delays GA 2-3 days minimum)

---

#### Timeline Impact

- **Current Plan:** GA production starts 1-JUN-2026
- **If Fixed by 31-MAY:** No schedule impact ✓
- **If Fixed by 2-JUN:** GA delayed 1 day (acceptable)
- **If Fixed by 5-JUN:** GA delayed 4 days (risk to 15-JUN schedule)
- **If Not Fixed:** GA blocked completely ✗

---

#### Detailing Readiness Impact

| Stage | Impact | Delay |
|-------|--------|-------|
| **GA Drawings** | ✗ BLOCKED | Cannot start without coordinates |
| **Erection Drawings** | ✗ BLOCKED | Depends on GA member locations |
| **3D Model** | ✗ BLOCKED | Cannot generate without coordinates |
| **Connection Details** | ✓ OK | Can proceed in parallel (secondary members, bracing complete) |
| **Fabrication Specs** | ✓ OK | Can proceed (section data available) |

---

### E-COBJ-002: Missing Primary Member Section Data (CRITICAL)

**ID:** E-COBJ-002  
**Title:** Missing section information for high-criticality primary members  
**Category:** Master Data - Material  
**Severity:** **CRITICAL**  
**Blocking:** **YES - Blocks Fabrication Specs**  
**Status:** OPEN  
**Owner:** Design Authority (design data owner)

---

#### Issue Details

**Affected Objects:**
1. OBJ-RF-COL-001 (Primary Column) - Section: NULL
2. OBJ-RF-COL-002 (Primary Column) - Section: NULL
3. OBJ-RF-RAF-001 (Primary Rafter) - Section: NULL

**Missing Fields:**
- Section_Start (cross-section at start node)
- Section_End (cross-section at end node; may differ if tapered)

**Current Status:**
- All 3 primary members lack section designation
- Section information available in 7_Primary_Member_Schedule (Handoff file)
- Objects frozen in design but section data not transferred to master

**Impact on Detailing:**

| Impact Area | Severity | Details |
|---|---|---|
| **GA Drawings** | CRITICAL | Cannot show member profile (tube/I-beam/built-up); profile essential for GA clarity |
| **Fabrication Specifications** | CRITICAL | Cannot specify section size to fabricator; leads to "Unknown Section" error |
| **Bill of Materials** | CRITICAL | Cannot generate weight, steel grade, or supply requirements without section |
| **Connection Design** | HIGH | Connection details depend on member section (gusset size, bolt patterns, weld prep) |
| **QC Inspection** | HIGH | Fabricator cannot inspect/verify delivered member without section specification |
| **Erection Planning** | MEDIUM | Member weight & handling requirements depend on section size |

**Root Cause:** Section information defined in frozen design (7_Primary_Member_Schedule, Handoff file) not transferred to Canonical_PEB_Object_Master. Master intended to be single source-of-truth but incomplete.

**Expected Data Source:**
- 7_Primary_Member_Schedule in Design_to_Detailing_Handoff.xlsx
- Frozen design specifications (MBMA codes, material grade, design standards)
- MBS model member properties (section library reference)

---

#### Resolution Path

**Step 1: Extract Section Data** (Immediate)
- Pull primary member sections from 7_Primary_Member_Schedule (Handoff file)
- Cross-reference with MBS model (member property export)
- Owner: Design Authority
- Timeline: **Same day** (simple data extraction)

**Step 2: Populate Master** (Within 24 hours)
- Enter Section_Start, Section_End for OBJ-RF-COL-001, OBJ-RF-COL-002, OBJ-RF-RAF-001
- Example format: "Built-up I-section 300x300x10 (ASME 340)" or "ISMB 400" or "Box 200x200x8"
- Owner: Design Authority
- Timeline: **By EOD 31-MAY-2026**

**Step 3: Validate Against Standards** (Within 24 hours)
- Confirm section designation matches code (MBMA, AISC, NAUS)
- Verify section available from stock/suppliers
- Check tolerances & mill availability
- Owner: Design Authority (design QA)
- Timeline: **By EOD 31-MAY-2026**

**Step 4: Update Fabrication Specs** (During Fab Spec phase)
- Incorporate section specifications into 7_Fabrication_Specifications
- Include section designation, grade, surface prep, weight
- Owner: Detailing team
- Timeline: **By 15-JUN-2026** (fabrication release date)

---

#### Timeline Impact

- **Current Plan:** Fabrication specs released 15-JUN-2026
- **If Fixed by 31-MAY:** No impact ✓
- **If Fixed by 10-JUN:** Minor impact (1-2 days); still meet 15-JUN deadline
- **If Fixed by 15-JUN:** Just-in-time; no schedule buffer
- **If Not Fixed:** Fabrication release delayed; impacts shop start (tentatively 1-JUL)

---

#### Detailing Readiness Impact

| Stage | Impact | Delay |
|-------|--------|-------|
| **GA Drawings** | MEDIUM | Can show generic member outline; ideal section still needed for detail |
| **Connection Details** | HIGH | Cannot finalize connection details without section properties |
| **Fabrication Specs** | ✗ BLOCKED | Cannot release fab specs without section designation |
| **Shop Release** | ✗ BLOCKED | Shop cannot bid or plan without section specified |
| **Fabrication Start** | ✗ DELAYED | Cannot begin fab without section specs; ~1-2 week delay possible |

---

## HIGH-SEVERITY EXCEPTIONS

### E-COBJ-003: Base Plate Missing Column Reference (HIGH)

**ID:** E-COBJ-003  
**Title:** Base Plate object missing Parent_Object_ID (column reference)  
**Category:** Master Data - Cross-Reference  
**Severity:** **HIGH**  
**Blocking:** **PARTIAL** (not GA; affects Anchor Bolt Plan clarity)  
**Status:** OPEN  
**Owner:** Design Authority

---

#### Issue Details

**Affected Object:**
- OBJ-BAS-001 (Base Plate assembly)

**Missing Field:**
- Parent_Object_ID (should reference OBJ-RF-COL-001, or OBJ-RF-COL-002, or both, or shared)

**Current Status:**
- Base plate object exists with complete geometry & design data
- Grid line shows "Below RF-COL" (qualitative)
- Parent column(s) undefined (quantitative cross-reference missing)

**Ambiguity:** Is OBJ-BAS-001 a:
1. Single base plate under one specific column? (If so, which: COL-001 or COL-002?)
2. Shared assembly under both columns? (If so, how distributed: symmetric, cantilever, etc.?)
3. Representative object for all similar base plates? (If so, what's the replication schedule?)

**Impact on Detailing:**

| Impact Area | Severity | Details |
|---|---|---|
| **Anchor Bolt Plan** | HIGH | Cannot trace OBJ-ABT-001 (bolts) → OBJ-BAS-001 (base) → OBJ-RF-COL-? (column); traceability chain broken |
| **Connection Detail Drawings** | HIGH | Unclear which column(s) the base plate serves; detailing team must infer design intent |
| **Erection Manual** | MEDIUM | Assembly sequence ambiguous (which column gets which base plate?) |
| **Fabrication Specifications** | MEDIUM | Bill of materials unclear on base plate quantity/specification |

**Root Cause:** Design intent for base plate configuration not captured in canonical master. Likely due to design decision (shared vs. individual) not yet finalized or documented in master.

---

#### Resolution Path

**Step 1: Clarify Design Intent** (Immediate)
- Decision: Is base plate per-column, or shared across multiple columns?
- Consult frozen design & base plate detail drawings
- Owner: Design Authority
- Timeline: **By 2-JUN-2026** (early detailing phase)

**Step 2: Update Master Structure** (Within 3 days)
- **Option A (Per-Column):** Create separate objects OBJ-BAS-001, OBJ-BAS-002 (one per column); populate Parent_Object_ID for each
- **Option B (Shared):** Keep OBJ-BAS-001; document shared design in Remarks field; create cross-reference list in child segment table
- Owner: Design Authority
- Timeline: **By 5-JUN-2026**

**Step 3: Link to Anchor Bolts** (Parallel with Step 2)
- Ensure OBJ-ABT-001.Parent = OBJ-BAS-001 (or OBJ-BAS-001/002/003 if multiple)
- Create clear hierarchy: Anchor Bolts → Base Plate → Column
- Owner: Design Authority
- Timeline: **By 5-JUN-2026**

**Step 4: Update Anchor Bolt Plan** (During detailing)
- Use corrected parent-child links to generate assembly drawings
- Owner: Detailing team
- Timeline: **By 10-JUN-2026** (before fabrication release 15-JUN)

---

#### Timeline Impact

- **Current Plan:** Anchor Bolt Plan finalization by 10-JUN-2026
- **If Fixed by 5-JUN:** No schedule impact ✓
- **If Fixed by 10-JUN:** Just-in-time; minimal buffer
- **If Not Fixed:** Anchor Bolt Plan delayed; impacts 15-JUN fabrication release window

---

### E-COBJ-004: Anchor Bolt Group Missing Base Plate Reference (HIGH)

**ID:** E-COBJ-004  
**Title:** Anchor Bolt object missing Parent_Object_ID (base plate reference)  
**Category:** Master Data - Cross-Reference  
**Severity:** **HIGH**  
**Blocking:** **PARTIAL** (not GA; affects Anchor Bolt Plan assembly)  
**Status:** OPEN  
**Owner:** Design Authority

---

#### Issue Details

**Affected Object:**
- OBJ-ABT-001 (Anchor Bolt Group)

**Missing Field:**
- Parent_Object_ID (should reference OBJ-BAS-001)

**Current Status:**
- Anchor bolt group exists with design mark "Foundation interface"
- Object_ID assigned: OBJ-ABT-001 ✓
- Parent reference missing: NULL

**Dependency on E-COBJ-003:** This exception dependent on resolution of base plate parent reference (E-COBJ-003). Cannot fully resolve until base plate object clarified.

**Impact on Detailing:**

| Impact Area | Severity | Details |
|---|---|---|
| **Anchor Bolt Plan** | HIGH | Cannot generate assembly showing which bolts belong to which base plate |
| **Traceability** | HIGH | Cannot trace: OBJ-ABT-001 (bolts) → OBJ-BAS-001 (base) → OBJ-RF-COL-? (column) |
| **Erection Sequence** | MEDIUM | Unclear which bolts to install with which base plate |
| **Fabrication Coordination** | MEDIUM | Anchor bolt specification references must link to base plate BOM |

**Root Cause:** Parent-child relationship not established. Likely oversight in canonical master generation; both OBJ-BAS-001 & OBJ-ABT-001 created but not linked.

---

#### Resolution Path

**Step 1: Resolve E-COBJ-003 First**
- Parent reference E-COBJ-003 (base plate) must be resolved first
- Once base plate parent defined, anchor bolt parent becomes clear
- Owner: Design Authority
- Timeline: **By 5-JUN-2026** (contingent on E-COBJ-003)

**Step 2: Populate Anchor Bolt Parent** (Parallel with Step 1)
- Once base plate finalized, set OBJ-ABT-001.Parent = OBJ-BAS-001 (or OBJ-BAS-001/002/003 if multiple)
- If multiple base plates, create separate anchor groups: OBJ-ABT-001, OBJ-ABT-002, etc.
- Owner: Design Authority
- Timeline: **By 5-JUN-2026**

**Step 3: Verify Traceability** (Within 1 day)
- Confirm chain: OBJ-ABT-001 → OBJ-BAS-001 → OBJ-RF-COL-001 (or equivalent)
- Check MBS analysis for anchor bolt reaction forces
- Owner: Design Authority (QA)
- Timeline: **By 6-JUN-2026**

**Step 4: Use in Anchor Bolt Plan** (During detailing)
- Generate assembly drawings using corrected parent-child hierarchy
- Owner: Detailing team
- Timeline: **By 10-JUN-2026** (before fabrication release)

---

#### Timeline Impact

- **Current Plan:** Anchor Bolt Plan finalization by 10-JUN-2026
- **If Fixed by 5-JUN:** No schedule impact ✓
- **If Fixed by 10-JUN:** Tight timeline; minimal buffer
- **If Not Fixed:** Anchor Bolt Plan delayed; impacts 15-JUN fabrication release

---

## EXCEPTION PRIORITY MATRIX

### By Blocking Severity

| Exception | Severity | Blocking | Type | Deadline | Action |
|-----------|----------|----------|------|----------|--------|
| **E-COBJ-001** | CRITICAL | **YES** | Geometry missing | **URGENT: 31-MAY** | Extract coordinates |
| **E-COBJ-002** | CRITICAL | **YES** | Geometry missing | **URGENT: 31-MAY** | Extract sections |
| **E-COBJ-003** | HIGH | PARTIAL | Cross-ref missing | By 5-JUN | Clarify design intent |
| **E-COBJ-004** | HIGH | PARTIAL | Cross-ref missing | By 5-JUN | Link to base plate |

### By Timeline

| Deadline | Exceptions | Action | Owner |
|----------|---|---|---|
| **ASAP (29-30 MAY)** | E-COBJ-001, E-COBJ-002 | Data extraction | Design Authority |
| **31-MAY EOD** | E-COBJ-001, E-COBJ-002 | Master population | Design Authority |
| **1-JUN morning** | E-COBJ-001, E-COBJ-002 | Release to detailing | Design Authority |
| **2-5 JUN** | E-COBJ-003, E-COBJ-004 | Design clarification & linking | Design Authority |
| **10-JUN** | E-COBJ-003, E-COBJ-004 | Anchor Bolt Plan finalization | Detailing team |

---

## DETAILING STAGE IMPACT ASSESSMENT

### Critical Exception Impact (E-COBJ-001, E-COBJ-002)

| Stage | Authorization | Blocker | Notes |
|-------|---|---|---|
| **Detailing Phase Initiation (1-JUN)** | ✓ AUTHORIZED | NO | Can proceed with other work |
| **GA Drawings (1-JUN)** | ✗ **BLOCKED** | **E-COBJ-001** (coordinates) | Primary member locations undefined |
| **Connection Details (1-JUN)** | ✓ AUTHORIZED | NO | Secondary/bracing members complete |
| **Erection Drawings (2-JUN)** | ✗ **BLOCKED** | **E-COBJ-001** (coordinates) | Depends on GA member locations |
| **Anchor Bolt Plan (1-JUN)** | ⚠ CONDITIONAL | **E-COBJ-003/004** (refs) | Secondary issue; can work around |
| **Fabrication Specs (15-JUN)** | ✗ **BLOCKED** | **E-COBJ-002** (sections) | Section data required for specs |
| **Erection Manual (30-JUN)** | ✓ AUTHORIZED | NO | Object inventory complete; detailing can proceed with provisional data |

### High Exception Impact (E-COBJ-003, E-COBJ-004)

| Stage | Authorization | Blocker | Notes |
|-------|---|---|---|
| **Anchor Bolt Plan Clarity** | ⚠ PARTIAL | **E-COBJ-003/004** | Can trace through comments; formal parent-child unclear |
| **Base Connection Detail** | ⚠ PARTIAL | **E-COBJ-003/004** | Column references ambiguous; can infer from design |
| **Erection Assembly Sequence** | ⚠ PARTIAL | **E-COBJ-003/004** | Sequence possible but not explicitly documented |

---

## IMMEDIATE ACTION ITEMS

### URGENT (Due ASAP - No Later Than 31-MAY EOD)

**Action 1: Extract & Populate Primary Member Coordinates**
- **What:** Populate Start_X/Y/Z, End_X/Y/Z for OBJ-RF-COL-001, OBJ-RF-COL-002, OBJ-RF-RAF-001
- **Source:** MBS model or 3_Grid_Geometry (Handoff file)
- **Owner:** Design Authority (MBS admin)
- **Effort:** ~2-4 hours (data extraction only; no design change)
- **Impact:** Unblocks GA production
- **Deadline:** EOD 31-MAY-2026 (48 hours from now)

**Action 2: Extract & Populate Primary Member Sections**
- **What:** Populate Section_Start, Section_End for OBJ-RF-COL-001, OBJ-RF-COL-002, OBJ-RF-RAF-001
- **Source:** 7_Primary_Member_Schedule (Handoff file) or MBS section library
- **Owner:** Design Authority (design data admin)
- **Effort:** ~1-2 hours (data lookup only; no design change)
- **Impact:** Unblocks fabrication specs
- **Deadline:** EOD 31-MAY-2026 (48 hours from now)

**Action 3: Release Updated Master Files**
- **What:** Export corrected Canonical_PEB_Object_Master.xlsx & .csv
- **Owner:** Design Authority
- **Effort:** ~30 minutes (file generation)
- **Deadline:** 1-JUN-2026 morning (before GA start)

---

### HIGH PRIORITY (Due By 5-JUN)

**Action 4: Clarify Base Plate Design Intent**
- **What:** Confirm whether OBJ-BAS-001 is per-column or shared; document decision
- **Owner:** Design Authority (with design team)
- **Effort:** ~2-4 hours (design review & documentation)
- **Deadline:** 5-JUN-2026 (before Anchor Bolt Plan work)

**Action 5: Link Base Plate to Column(s)**
- **What:** Populate OBJ-BAS-001.Parent = OBJ-RF-COL-001 (or similar); or restructure if shared
- **Owner:** Design Authority
- **Effort:** ~1-2 hours (master update)
- **Deadline:** 5-JUN-2026

**Action 6: Link Anchor Bolts to Base Plate**
- **What:** Populate OBJ-ABT-001.Parent = OBJ-BAS-001; ensure traceability chain complete
- **Owner:** Design Authority
- **Effort:** ~1 hour (master update)
- **Deadline:** 5-JUN-2026

---

## EXCEPTION TRACKING & CLOSEOUT

### Tracking Method

**Weekly Status Updates:** Every Friday during detailing phase
- Update exception status: OPEN → IN_PROGRESS → RESOLVED → CLOSED
- Track data population % complete
- Identify blockers or delays
- Escalate if timeline at risk

**Closeout Criteria:**

| Exception | Closeout Criteria | Validation |
|-----------|---|---|
| E-COBJ-001 | Coordinates populated for 3 members; validated against grid geometry | Design Authority QA sign-off |
| E-COBJ-002 | Sections populated for 3 members; confirmed available from suppliers | Design Authority QA sign-off |
| E-COBJ-003 | Base plate parent reference populated; design intent documented | Design Authority sign-off |
| E-COBJ-004 | Anchor bolt parent reference populated; traceability chain verified | Design Authority sign-off |

---

## EXCEPTION LOG SUMMARY TABLE

| ID | Title | Severity | Blocking | Status | Owner | Deadline | Action |
|---|---|---|---|---|---|---|---|
| E-COBJ-001 | Missing primary member coordinates | CRITICAL | **YES** | OPEN | Design Authority | 31-MAY | Extract coordinates |
| E-COBJ-002 | Missing primary member sections | CRITICAL | **YES** | OPEN | Design Authority | 31-MAY | Extract sections |
| E-COBJ-003 | Base plate missing column ref | HIGH | PARTIAL | OPEN | Design Authority | 5-JUN | Clarify & link |
| E-COBJ-004 | Anchor bolt missing base ref | HIGH | PARTIAL | OPEN | Design Authority | 5-JUN | Link to base plate |

---

## VALIDATION CONCLUSION

**High-Criticality Exception Assessment:** ⚠ **BLOCKING ISSUES IDENTIFIED**

**Summary:**
- 2 critical exceptions block GA & fabrication specs
- 2 high exceptions create partial blocks for Anchor Bolt Plan clarity
- All 4 exceptions have clear resolution paths
- Critical path: E-COBJ-001 & E-COBJ-002 must be resolved by 31-MAY (48 hours)
- High priority: E-COBJ-003 & E-COBJ-004 must be resolved by 5-JUN (for 10-JUN Anchor Bolt Plan)

**Recommendation:** **PAUSE GA PRODUCTION** until E-COBJ-001 & E-COBJ-002 resolved. Proceed with connection detail & secondary member design in parallel. Resolve E-COBJ-003 & E-COBJ-004 by 5-JUN for Anchor Bolt Plan work.

---

**Report Classification:** DESIGN AUTHORITY BASELINE  
**Date:** 6-MAY-2026  
**Escalation Level:** CHIEF ENGINEER (urgent 48-hour deadline)  
**Next Review:** 1-JUN-2026 (confirm URGENT items completed)
