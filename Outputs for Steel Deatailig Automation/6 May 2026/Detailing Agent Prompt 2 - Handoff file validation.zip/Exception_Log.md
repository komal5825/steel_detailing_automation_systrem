# EXCEPTION LOG (Complete)
## C163-027 Saswad Industrial Shed & Crane Building

**Report Date:** 6-MAY-2026  
**Exception Count:** 15  
**Blocking Exceptions:** 0  
**High-Criticality:** 2  
**Medium-Criticality:** 5  
**Low-Criticality:** 8

---

## EXCEPTION LOG SUMMARY

| Category | Count | Blocking | Impact on Detailing |
|----------|-------|----------|-------------------|
| **High-Criticality** | 2 | NO | Non-blocking; resolution required before fabrication |
| **Medium-Criticality** | 5 | NO | Non-blocking; routine detailing work items |
| **Low-Criticality** | 8 | NO | Non-blocking; parallel/future work items |
| **TOTAL** | **15** | **0** | **All non-blocking** |

---

## EXCEPTION DETAIL LOG

---

## HIGH-CRITICALITY EXCEPTIONS (2 items)

### E-002: Foundation Design Out of Scope
**Status:** ACKNOWLEDGED  
**Severity:** HIGH  
**Issue:** Foundation structural design (footings, piles) is outside scope of PEB design contract.

| Field | Value |
|-------|-------|
| **ID** | E-002 |
| **Title** | Foundation design out of scope |
| **Category** | Scope Exclusion |
| **Blocking Detailing** | NO |
| **Blocking Fabrication** | NO |
| **Blocking Erection** | NO |
| **Impact Area** | Foundation phase (separate from PEB) |
| **Status** | ACKNOWLEDGED |
| **Owner** | Project Manager (scope management) |
| **Resolution** | Foundation design to be performed by separate structural engineer; interface coordinates to be confirmed by PEB during final design. |
| **Target Resolution** | Before fabrication release (15-JUN-2026) |
| **Detailing Action** | Provide foundation interface drawing (base plate elevations, anchor bolt reactions). |
| **Notes** | Standard for PEB projects; no impact on structural design. |

**Why NOT Blocking:**
- Acknowledged and documented scope exclusion
- Clear responsibility assignment (separate consultant)
- Foundation design does not affect PEB member design
- Interface data available in Base_Plate_Seed

---

### E-003: Soil Bearing Capacity Not Verified
**Status:** NEEDS_GEOTECHNICAL  
**Severity:** HIGH  
**Issue:** Geotechnical soil bearing capacity and foundation design not yet verified by geotechnical consultant.

| Field | Value |
|-------|-------|
| **ID** | E-003 |
| **Title** | Soil bearing capacity not verified |
| **Category** | External Input Required |
| **Blocking Detailing** | NO |
| **Blocking Fabrication** | NO |
| **Blocking Erection** | NO (foundation work separate) |
| **Impact Area** | Anchor bolt length finalization, foundation design |
| **Status** | NEEDS_GEOTECHNICAL |
| **Owner** | Geotechnical Consultant (client-engaged) |
| **Resolution** | Geotechnical report to provide: (1) soil bearing capacity, (2) settlement analysis, (3) foundation design recommendations. PEB to update anchor bolt lengths based on final foundation elevation. |
| **Target Resolution** | Before fabrication release (15-JUN-2026) |
| **Detailing Action** | Use provisional anchor bolt seed data; finalize based on geotechnical report. |
| **Provisional Assumption** | Base elevation GL+0.6m (per E-001); anchor bolt lengths TBD. |
| **Timeline Impact** | ~2 weeks for geotechnical report (typical); detailing proceeds in parallel. |
| **Notes** | Standard geotechnical input for PEB projects; non-blocking for detailing phase. |

**Why NOT Blocking:**
- Geotechnical report scope is separate from structural detailing
- Detailing can proceed using provisional base elevation
- Anchor bolt lengths finalized after geotechnical report received
- No design changes required (only clarification of existing assumptions)

---

## MEDIUM-CRITICALITY EXCEPTIONS (5 items)

### E-001: Base Elevation Not Confirmed
**Status:** NEEDS_CLIENT_INPUT  
**Severity:** MEDIUM  
**Issue:** Base elevation (finished floor level) not confirmed by client.

| Field | Value |
|-------|-------|
| **ID** | E-001 |
| **Title** | Base Elevation (GL+0.6m) not confirmed |
| **Category** | Client Input Required |
| **Blocking Detailing** | NO |
| **Impact Area** | Anchor bolt length, base plate design |
| **Status** | NEEDS_CLIENT_INPUT |
| **Owner** | Client (with Detailing Lead confirmation) |
| **Current Assumption** | GL+0.6m (provisional) |
| **Variance Tolerance** | ±0.5m (requires re-design if exceeded) |
| **Resolution** | Client to confirm final base elevation (FFL). PEB to update anchor bolt lengths accordingly. |
| **Target Resolution** | Before fabrication release (10-JUN-2026) |
| **Detailing Action** | Proceed with provisional GL+0.6m; prepare alternative bolt length drawings for ±0.5m variance. |
| **Fabrication Impact** | Anchor bolts may require re-cutting if elevation confirmed different; ~2-3 days impact on shop schedule. |
| **Notes** | Standard client confirmation in PEB projects. Non-blocking for detailing. |

**Why NOT Blocking:**
- Provisional assumption available (GL+0.6m)
- Detailing can proceed; finalize before fabrication release
- Anchor bolt seed data accommodates variance
- Timeline allows for resolution before fabrication cutoff

---

### E-004: Crane Hoist Tonnage Not Confirmed
**Status:** NEEDS_CLIENT_INPUT  
**Severity:** MEDIUM  
**Issue:** Crane hoist tonnage capacity not confirmed by client; affects bracing design if >2T.

| Field | Value |
|-------|-------|
| **ID** | E-004 |
| **Title** | Crane hoist tonnage not confirmed |
| **Category** | Client Input Required (Equipment Spec) |
| **Blocking Detailing** | NO |
| **Impact Area** | Bracing system (if tonnage >2T); lateral load paths |
| **Status** | NEEDS_CLIENT_INPUT |
| **Owner** | Client (Equipment procurement); Design Authority (load path verification) |
| **Current Assumption** | ≤2T hoist (conservative); design assumes diagonal rod bracing adequate for 2T lateral load. |
| **Confirmation Required** | Client to confirm hoist tonnage and location. |
| **Design Impact** | If tonnage >2T → increased lateral bracing required; design review needed. |
| **Resolution** | Client to confirm hoist tonnage. If >2T, Design Authority to review bracing and issue DCO if changes required. |
| **Target Resolution** | Before fabrication release (15-JUN-2026) |
| **Detailing Action** | Proceed with ≤2T assumption (bracing design complete per 9_Bracing_Schedule). If client confirms >2T, defer fabrication pending bracing DCO. |
| **Timeline Impact** | ~3-5 days for design review if tonnage >2T; may delay fabrication release. |
| **Notes** | Crane hoist equipment specifications typically confirm tonnage early in project. Detailing proceeds using conservative assumption. |

**Why NOT Blocking:**
- Conservative assumption (≤2T) available and reasonable
- Bracing design complete for current assumption
- Resolution clear: confirm tonnage before fabrication
- If higher tonnage confirmed, well-defined DCO process in place

---

### E-007: Welding QC Plan (Inspection Coverage TBD)
**Status:** PROVISIONAL  
**Severity:** MEDIUM  
**Issue:** Welding quality control plan and inspection coverage (% UT or alternative) not yet specified.

| Field | Value |
|-------|-------|
| **ID** | E-007 |
| **Title** | Welding QC plan 100% UT coverage TBD |
| **Category** | Detailing Phase Work |
| **Blocking Detailing** | NO |
| **Impact Area** | Fabrication specifications, QC procedures, cost/schedule |
| **Status** | PROVISIONAL |
| **Owner** | Detailing Team (with Design Authority input) |
| **Provisional Assumption** | 100% visual inspection + 10% ultrasonic testing (UT) per AISC standards |
| **Alternative Options** | (1) 100% visual + 10% UT (assumed), (2) 100% visual + 100% UT (higher cost), (3) 100% visual + zero UT (lower cost, higher risk). |
| **Design Authority Responsibility** | Specify QC plan based on code & client requirements (E-007 flagged as provisional). |
| **Resolution** | Design Authority to issue welding QC specification during fabrication spec phase (by 15-JUN-2026). Coordinate with client on acceptance criteria. |
| **Detailing Action** | Use provisional 100% visual + 10% UT assumption; detail weld schedules accordingly. Finalize in fabrication specs. |
| **Cost/Schedule Impact** | Varies by option: 10% UT ~standard cost/schedule; 100% UT ~15-20% additional cost & 1-2 weeks schedule. |
| **Notes** | Standard detailing phase decision; frequently deferred to detailed design stage. No design impact, only QC procedure. |

**Why NOT Blocking:**
- Provisional assumption available (standard practice)
- Decision deferred to fabrication spec phase (appropriate)
- Detailing can proceed; QC plan finalized later
- Does not affect member design or capacity
- Well-established alternative procedures available

---

### E-008: Temporary Erection Bracing Design
**Status:** INCOMPLETE  
**Severity:** MEDIUM  
**Issue:** Temporary erection bracing (during assembly) design not yet detailed.

| Field | Value |
|-------|-------|
| **ID** | E-008 |
| **Title** | Temporary erection bracing design |
| **Category** | Detailing Phase Work |
| **Blocking Detailing** | NO |
| **Impact Area** | Erection Manual, temporary load paths, site safety |
| **Status** | INCOMPLETE (assigned to detailing phase) |
| **Owner** | Detailing Team (with Erection Contractor input) |
| **Current Status** | 2-bay frame lifting sequence approved (portable gantry + spreader beam); temporary bracing to be designed in detail. |
| **Resolution** | Detailing team to: (1) Analyze temporary load cases (lifting, assembly phases), (2) Design temporary diagonal bracing & guys, (3) Prepare erection sequence drawings, (4) Coordinate with erection contractor for site-specific requirements. |
| **Target Completion** | By 30-JUN-2026 (Erection Manual preparation) |
| **Detailing Action** | Assign temporary bracing design to senior detailer; input erection contractor early for site constraints. |
| **Coordination** | Erection Manual to include: (1) Temporary load paths, (2) Temporary member sizes, (3) Installation sequence, (4) Safety requirements. |
| **Notes** | Standard detailing phase work; not completed in design phase. Critical for site safety & fabrication sequencing. |

**Why NOT Blocking:**
- Correctly assigned to detailing phase
- 2-bay lifting sequence already approved (foundation for temporary design)
- Well-established temporary bracing engineering practices
- Erection contractor can provide input during detailing
- Does not affect permanent member design

---

### E-013: Temporary Erection Bracing Detailed Design
**Status:** INCOMPLETE  
**Severity:** MEDIUM  
**Issue:** Detailed design of temporary erection bracing (braces, guys, connections) to be completed in detailing phase.

| Field | Value |
|-------|-------|
| **ID** | E-013 |
| **Title** | Temporary erection bracing (detailed design) |
| **Category** | Detailing Phase Work |
| **Blocking Detailing** | NO |
| **Impact Area** | Erection Manual, Erection Method Statement (EMS) |
| **Status** | INCOMPLETE (assigned to detailing) |
| **Owner** | Detailing Team + Erection Contractor (collaborative design) |
| **What's Known** | 2-bay frame lifting sequence approved (portable gantry, spreader beam, temporary props). |
| **What's Needed** | (1) Temporary diagonal bracing rod sizing, (2) Guy rope specifications, (3) Temporary connection details, (4) Temporary load analysis. |
| **Resolution** | Detailing team to work with erection contractor: (1) Confirm site access & constraints, (2) Design temporary bracing for lifting & assembly loads, (3) Prepare Erection Method Statement (EMS), (4) Coordinate temporary member supply with fabricator. |
| **Target Completion** | By 30-JUN-2026 (Erection Manual ready for site) |
| **Detailing Task** | (a) Load analysis for temporary assembly phases, (b) Temporary member sizing, (c) Detail temporary connections (bolts, welds), (d) Erection sequence drawings. |
| **Erection Contractor Task** | (a) Site logistics & constraints, (b) Equipment availability & capacity, (c) Method statement preparation. |
| **Integration** | Results to be included in Erection Manual (part of detailing deliverables). |
| **Notes** | Typical detailing phase responsibility in PEB projects; frequently includes fabricator input on temporary member sequencing. |

**Why NOT Blocking:**
- Appropriate assignment to detailing phase
- Strong foundation (2-bay lifting sequence approved)
- Clear scope (temporary bracing design & EMS)
- Erection contractor engagement plan in place
- Does not affect permanent structure design

---

## LOW-CRITICALITY EXCEPTIONS (8 items)

### E-005: Paint System Specification TBD
**Status:** PROVISIONAL  
**Severity:** LOW  
**Issue:** Final paint system (type, thickness, surface prep) not yet specified.

| Field | Value |
|-------|-------|
| **ID** | E-005 |
| **Title** | Paint system specification TBD |
| **Category** | Detailing Phase Work |
| **Blocking Detailing** | NO |
| **Impact Area** | Fabrication specs, surface preparation, cost |
| **Status** | PROVISIONAL |
| **Owner** | Detailing Team (Design Authority input) |
| **Provisional Assumption** | Aluzinc sheeting + Polyester/polyurethane paint on primary steel (2-coat system, 100µm DFT) |
| **Alternatives** | (1) Hot-dip galvanize (HDG) + no additional paint, (2) Sherardized + paint, (3) Bare steel + 2-coat paint system. |
| **Resolution** | Design Authority to specify paint system in fabrication specs (by 15-JUN-2026) based on: corrosion exposure (industrial/coastal/marine), budget, client preference. |
| **Detailing Action** | Proceed with provisional system; finalize during fabrication spec phase. |
| **Fabricator Impact** | Paint system affects fabrication cost (~5-10%) and shop schedule (~1-2 weeks). |
| **Notes** | Standard detailing-phase decision; typically part of fabrication spec package. Provisional assumption sufficient for design. |

**Why NOT Blocking:**
- Provisional assumption available (adequate for design)
- Detailing decision, not structural design change
- Multiple standard systems available
- Finalized during fabrication spec phase
- Does not affect member sizing or capacity

---

### E-006: Bolt Surface Treatment (Zinc/Painted TBD)
**Status:** PROVISIONAL  
**Severity:** LOW  
**Issue:** Anchor bolt and connection bolt surface treatment (galvanized, zinc-plated, or painted) not yet specified.

| Field | Value |
|-------|-------|
| **ID** | E-006 |
| **Title** | Bolt surface treatment (zinc/painted) |
| **Category** | Detailing Phase Work |
| **Blocking Detailing** | NO |
| **Impact Area** | Fabrication specs, corrosion protection, cost |
| **Status** | PROVISIONAL |
| **Owner** | Detailing Team (Design Authority input) |
| **Provisional Assumption** | Zinc-plated anchor bolts (Class 8.8, per IS 6623) + corrosion protection per site exposure |
| **Alternatives** | (1) Hot-dip galvanized (HDG) bolts, (2) Stainless steel bolts (marine exposure), (3) Painted mild steel bolts (covered/sheltered locations). |
| **Resolution** | Detailing Team to specify bolt treatment in fabrication specs (by 15-JUN-2026) based on site exposure & maintenance plan. |
| **Detailing Action** | Proceed with zinc-plated assumption; finalize in fabrication specs. |
| **Fabricator Impact** | Minimal; standard sizing not affected. Cost varies: zinc-plated ~standard, HDG ~10-15% additional cost. |
| **Notes** | Routine detailing specification; typically included in fabrication bill of materials. |

**Why NOT Blocking:**
- Provisional assumption standard & adequate
- No structural impact (capacity unchanged)
- Finalized during fabrication spec phase
- Standard material availability for all options
- Cost impact minimal & predictable

---

### E-009: Fabricator Drawing Coordination
**Status:** ROUTINE  
**Severity:** LOW  
**Issue:** Fabricator involvement in detailing review & drawing coordination not yet scheduled.

| Field | Value |
|-------|-------|
| **ID** | E-009 |
| **Title** | Fabricator drawing coordination pending |
| **Category** | Detailing Process |
| **Blocking Detailing** | NO |
| **Impact Area** | Fabrication feasibility, schedule, cost |
| **Status** | ROUTINE (standard detailing task) |
| **Owner** | Detailing Lead (Fabricator engagement) |
| **Task** | Coordinate detailed drawings with selected fabricator for: (1) fabrication feasibility review, (2) cost optimization, (3) sequence & schedule input, (4) equipment capacity confirmation. |
| **Timeline** | Fabricator engagement typically after fabrication specs complete (15-JUN-2026). Coordination review 5-7 days. |
| **Detailing Action** | (1) Issue RFQ for fabrication to pre-qualified vendors, (2) Select fabricator, (3) Issue detailed drawings for coordination review, (4) Incorporate feedback into final fab package. |
| **Integration** | Fabricator confirmation typically precedes formal shop release (by ~1-2 weeks). |
| **Notes** | Standard PEB detailing workflow; routine coordination task. |

**Why NOT Blocking:**
- Standard detailing process step
- Scheduled appropriately after detail design
- Well-defined workflow for coordination
- Fabricator input improves final product quality
- No design impact; optimization only

---

### E-010: Erection Manual Walkway Provisions
**Status:** ROUTINE  
**Severity:** LOW  
**Issue:** Walkway provisions & access routes in Erection Manual to be detailed.

| Field | Value |
|-------|-------|
| **ID** | E-010 |
| **Title** | Erection manual walkway provisions |
| **Category** | Detailing / Erection Planning |
| **Blocking Detailing** | NO |
| **Impact Area** | Erection Manual, site safety, construction planning |
| **Status** | ROUTINE (standard erection documentation task) |
| **Owner** | Detailing Team + Erection Contractor |
| **Task** | Prepare erection sequence drawings showing: (1) Safe access routes for workers, (2) Equipment positioning, (3) Temporary walkways/access points, (4) Load zones & exclusion areas. |
| **Timeline** | Included in Erection Manual (by 30-JUN-2026). |
| **Detailing Action** | Work with erection contractor to finalize site-specific access/walkway requirements. |
| **Integration** | Erection Manual to include: (1) Standard safety provisions, (2) Site-specific layouts, (3) Coordination with client site constraints. |
| **Notes** | Standard erection documentation; typically collaborative effort between detailing & erection teams. |

**Why NOT Blocking:**
- Routine erection planning task
- Incorporated in Erection Manual (scheduled work)
- Erection contractor input ensures site feasibility
- No design impact; logistics & safety focus
- Standard procedure in PEB erection planning

---

### E-011: Safety Railings (Non-Structural)
**Status:** ROUTINE  
**Severity:** LOW  
**Issue:** Safety railings & guardrails on accessible elevated surfaces to be specified.

| Field | Value |
|-------|-------|
| **ID** | E-011 |
| **Title** | Safety railings (non-structural) |
| **Category** | Detailing / Site Safety |
| **Blocking Detailing** | NO |
| **Impact Area** | Erection Manual, site safety specifications |
| **Status** | ROUTINE (detailing coordination) |
| **Owner** | Detailing Team (Safety Engineer input) |
| **Task** | Specify railing systems for: (1) Roof walkways/access points, (2) Maintenance platforms, (3) Load assembly areas. Confirm with local site safety requirements & client standards. |
| **Requirements** | Per IS 1165 (Safety Code) or equivalent: minimum 1.1m height, ~40 kN horizontal load capacity (non-structural requirement). |
| **Detailing Action** | (1) Identify elevated access points on GA drawings, (2) Specify railing type (pipe, cable, balusters), (3) Provide mounting details on member connection drawings. |
| **Integration** | Railing details to be included in fabrication specs & Erection Manual. |
| **Notes** | Non-structural detailing; coordinates with site safety plan. Typical PEB project deliverable. |

**Why NOT Blocking:**
- Non-structural work (safety feature, not load-bearing)
- Specified during detailing phase (appropriate timing)
- Standard safety requirements & solutions available
- Does not affect member design or capacity
- Routine coordination with site safety team

---

### E-012: Roof Drainage Design TBD
**Status:** ROUTINE  
**Severity:** LOW  
**Issue:** Roof drainage system design (gutters, downspouts, slopes) to be finalized.

| Field | Value |
|-------|-------|
| **ID** | E-012 |
| **Title** | Roof drainage design TBD |
| **Category** | Detailing / Architectural Interface |
| **Blocking Detailing** | NO |
| **Impact Area** | Erection Manual, roofing coordination, site utilities |
| **Status** | ROUTINE (architectural/MEP coordination) |
| **Owner** | Architectural/MEP team (outside PEB scope) |
| **Task** | Design roof drainage system: (1) Gutter sizing & slopes, (2) Downspout routing & discharge, (3) Coordination with site drainage. |
| **PEB Responsibility** | Provide roof geometry & slope (already available: 10:100 slope per frozen design). Interface points for drainage attachment. |
| **Detailing Action** | Confirm with architectural team: (1) Gutter attachment points on primary rafters, (2) Downspout clearances & routing, (3) Integration with facade/wall systems. |
| **Timeline** | Typically architectural/MEP deliverable; coordinate during detailing phase. |
| **Integration** | Roof drainage details referenced in Erection Manual & MEP coordination drawings. |
| **Notes** | Outside primary PEB structural scope; coordination task during detailing. |

**Why NOT Blocking:**
- Outside PEB structural scope (architectural/MEP responsibility)
- PEB provides interface geometry (roof slope locked)
- Routine coordination task during detailing
- Does not affect member design or capacity
- Standard detailing-phase interface management

---

### E-014: Nameplate & Documentation Schedule
**Status:** ROUTINE  
**Severity:** LOW  
**Issue:** Nameplate specifications & documentation schedule (as-built drawings, manuals) to be defined.

| Field | Value |
|-------|-------|
| **ID** | E-014 |
| **Title** | Nameplate & documentation schedule |
| **Category** | Detailing / Project Administration |
| **Blocking Detailing** | NO |
| **Impact Area** | Fabrication specs, handover documentation, project closeout |
| **Status** | ROUTINE (project administration task) |
| **Owner** | Project Manager (Detailing Lead input) |
| **Task** | Prepare documentation schedule: (1) Building nameplate & identification markers, (2) As-built drawing responsibility (fabricator vs. detailing), (3) Operation & maintenance manuals, (4) Warranty documentation. |
| **Detailing Action** | (1) Coordinate nameplate format & location on drawings, (2) Define as-built drawing scope & delivery schedule, (3) Prepare bill of materials & parts list for O&M manual. |
| **Timeline** | Typically finalized in shop release package (by 1-JUL-2026). |
| **Integration** | Documentation schedule included in fabrication specs & shop release documents. |
| **Notes** | Standard project administration task; routine in PEB detailing workflows. |

**Why NOT Blocking:**
- Administrative task (not structural design)
- Finalized during shop release phase
- Standard procedures & templates available
- Does not affect member design or fabrication
- Routine project closeout documentation

---

### E-015: As-Built Drawing Responsibility
**Status:** ROUTINE  
**Severity:** LOW  
**Issue:** Responsibility & timeline for as-built drawing preparation (fabricator vs. erection contractor vs. owner) to be clarified.

| Field | Value |
|-------|-------|
| **ID** | E-015 |
| **Title** | As-built drawing responsibility |
| **Category** | Project Administration / Handover |
| **Blocking Detailing** | NO |
| **Impact Area** | Project closeout, operational records |
| **Status** | ROUTINE (contract/admin clarification) |
| **Owner** | Project Manager (with Fabricator/Erection Contractor input) |
| **Issue** | Responsibility for as-built drawings (documenting actual site conditions post-erection) not yet assigned. Options: (1) Fabricator (based on shop fab drawings), (2) Erection Contractor (based on site installation), (3) Owner (post-handover). |
| **Resolution** | Project Manager to clarify in shop release contract: (1) Who prepares as-builts, (2) Scope (dimensions, deviations, modifications, site changes), (3) Delivery timeline (before or after handover). |
| **Detailing Action** | Provide baseline detailed drawings in shop release package for as-built comparison. |
| **Timeline** | Responsibility clarified before shop release (by 1-JUL-2026). |
| **Integration** | As-built drawing requirements included in shop release specifications & contract documents. |
| **Notes** | Standard project closeout item; typically specified in contract terms. Routine for PEB projects. |

**Why NOT Blocking:**
- Administrative responsibility clarification (not design)
- Finalized in contract/shop release phase
- Standard responsibilities well-established
- Does not affect member design or fabrication
- Routine project closeout requirement

---

## EXCEPTION PRIORITY & RESOLUTION MATRIX

### Priority 1: Critical Input (Must resolve before fabrication release)

| ID | Title | Owner | Target Date | Status |
|---|---|---|---|---|
| E-001 | Base Elevation confirmation | Client | 10-JUN-2026 | NEEDS_CLIENT_INPUT |
| E-003 | Soil bearing capacity report | Geotechnical | 10-JUN-2026 | NEEDS_GEOTECHNICAL |
| E-004 | Crane tonnage confirmation | Client | 15-JUN-2026 | NEEDS_CLIENT_INPUT |

**Timeline:** 4-9 days for resolution (before fabrication release 15-JUN-2026).

---

### Priority 2: Detailing Phase Work (Resolve during detailed design)

| ID | Title | Owner | Target Date | Status |
|---|---|---|---|---|
| E-005 | Paint system spec | Detailing + Design Authority | 15-JUN-2026 | PROVISIONAL |
| E-006 | Bolt surface treatment | Detailing + Design Authority | 15-JUN-2026 | PROVISIONAL |
| E-007 | Welding QC plan | Detailing + Design Authority | 15-JUN-2026 | PROVISIONAL |
| E-008 | Temporary erection bracing | Detailing + Erection Contractor | 30-JUN-2026 | INCOMPLETE |
| E-013 | Erection bracing detailed design | Detailing + Erection Contractor | 30-JUN-2026 | INCOMPLETE |

**Timeline:** 4-8 weeks (integrated into Detailing & Erection Manual phase).

---

### Priority 3: Routine Coordination (Ongoing throughout detailing)

| ID | Title | Owner | Target Date | Status |
|---|---|---|---|---|
| E-009 | Fabricator coordination | Detailing Lead | 15-JUN-2026 | ROUTINE |
| E-010 | Erection manual walkways | Detailing + Erection | 30-JUN-2026 | ROUTINE |
| E-011 | Safety railings | Detailing + Safety | 30-JUN-2026 | ROUTINE |
| E-012 | Roof drainage design | Architectural/MEP | 30-JUN-2026 | ROUTINE |
| E-014 | Nameplate & documentation | Project Manager | 1-JUL-2026 | ROUTINE |
| E-015 | As-built drawing responsibility | Project Manager | 1-JUL-2026 | ROUTINE |

**Timeline:** Parallel with detailing phase work.

---

### Priority 4: Acknowledged Out-of-Scope (External phase)

| ID | Title | Owner | Target Date | Status |
|---|---|---|---|---|
| E-002 | Foundation design | Separate consultant | Before erection | ACKNOWLEDGED |

**Timeline:** Separate project phase; coordinate interface via base plate elevations.

---

## EXCEPTION IMPACT ON DETAILING PHASES

### Phase Impact Analysis

| Phase | Exception Dependency | Blocking | Resolution Required | Workaround |
|---|---|---|---|---|
| **Phase 1: GA Drawings** | None | NO | None | Proceed |
| **Phase 2: Connection Details** | E-007 (QC plan) | NO | Detailing phase | Use standard assumptions |
| **Phase 3: Anchor Bolt Plan** | E-001, E-003 | NO | Before fab release | Use provisional elevations |
| **Phase 4: Primary Member Details** | None | NO | None | Proceed |
| **Phase 5: Secondary/Bracing** | E-004 (tonnage) | NO | Before fab release | Use ≤2T assumption |
| **Phase 6: Fab Specs** | E-005, E-006, E-007 | NO | During this phase | Finalize specifications |
| **Phase 7: Erection Manual** | E-008, E-010, E-013 | NO | During this phase | Design temporary systems |
| **Phase 8: Shop Release** | E-001, E-003, E-004 | NO | Before release | Incorporate client/geotech inputs |

**Conclusion:** No exceptions block any detailing phase. All exceptions have clear resolution paths and timelines.

---

## EXCEPTION TRACKING & CLOSEOUT

### Resolution Accountability

| Category | Count | Owner | Tracking Method | Closeout Criteria |
|----------|-------|-------|-----------------|------------------|
| **Client Input** | 2 (E-001, E-004) | Client with PM | Email + meeting notes | Written confirmation + updated drawings |
| **Geotechnical** | 1 (E-003) | Geotech consultant | Formal report | Report receipt + incorporation into design |
| **Design Authority** | 3 (E-005, E-006, E-007) | Design Authority | Design specification doc | Specification issued & incorporated into fab specs |
| **Detailing Team** | 5 (E-008, E-009, E-010, E-011, E-014) | Detailing Lead | Design drawings & manuals | Drawings complete & included in deliverables |
| **Project Admin** | 2 (E-012, E-015) | Project Manager | Contract/scope document | Responsibility assigned & documented |
| **Acknowledged Scope** | 1 (E-002) | Separate consultant | Project coordination notes | Interface drawing complete |

### Tracking Schedule

**Weekly Status Review:** Every Friday during detailing phase (starting 1-JUN-2026)
- Exception status update (open → in-progress → closed)
- Risk mitigation (e.g., re-design impact if client input delayed)
- Escalation path (if target date at risk)

**Monthly Detailing Review:** 15-JUN-2026, 30-JUN-2026
- Exception closeout summary
- Impact on downstream phases
- Schedule risk assessment

**Fabrication Release Gate Review:** Before 15-JUN-2026
- Confirm E-001, E-003, E-004 status
- If unresolved: define contingency (e.g., hold fabric release, use provisional, reduce shop time)
- Final decision authority: Design Authority + Project Manager

---

## DETAILING TEAM EXCEPTION MANAGEMENT DIRECTIVES

**During Detailing Phase:**

1. **Priority 1 Exceptions (E-001, E-003, E-004):**
   - Weekly follow-up with Client / Geotechnical consultant
   - Prepare provisional design using assumptions; flagged as TBD
   - Ready alternative designs (e.g., bolt length variants) for rapid incorporation when inputs received
   - Escalate if target date (10-15 JUN) at risk; initiate contingency plan

2. **Priority 2 Exceptions (E-005 to E-008, E-013):**
   - Prepare draft specifications using standard practices
   - Submit to Design Authority for review by 10-JUN-2026
   - Incorporate feedback into fabrication specs (release 15-JUN-2026)

3. **Priority 3 Exceptions (E-009 to E-015):**
   - Execute as routine detailing tasks
   - Document decisions in drawing notes & spec documents
   - Include in final deliverables (GA drawings, Fab specs, Erection Manual)

4. **Exception Log Maintenance:**
   - Update status weekly
   - Close exceptions when criteria met
   - Generate monthly closeout report

---

## EXCEPTION LOG SUMMARY TABLE (Quick Reference)

| ID | Title | Severity | Status | Owner | Target | Blocking | Notes |
|---|---|---|---|---|---|---|---|
| E-001 | Base Elevation | MEDIUM | NEEDS_INPUT | Client | 10-JUN | NO | Provisional GL+0.6m |
| E-002 | Foundation OOS | HIGH | ACKNOWLEDGED | External | Later | NO | Separate phase |
| E-003 | Soil Bearing | HIGH | NEEDS_GEOTECH | Geotech | 10-JUN | NO | Report required |
| E-004 | Crane Tonnage | MEDIUM | NEEDS_INPUT | Client | 15-JUN | NO | ≤2T assumed |
| E-005 | Paint System | LOW | PROVISIONAL | Design Auth | 15-JUN | NO | Standard option assumed |
| E-006 | Bolt Treatment | LOW | PROVISIONAL | Design Auth | 15-JUN | NO | Zinc-plated assumed |
| E-007 | Welding QC | MEDIUM | PROVISIONAL | Design Auth | 15-JUN | NO | 100% visual + 10% UT assumed |
| E-008 | Temp Bracing | MEDIUM | INCOMPLETE | Detailing | 30-JUN | NO | Assigned to detail phase |
| E-009 | Fab Coordination | LOW | ROUTINE | Detailing | 15-JUN | NO | Standard task |
| E-010 | Erection Walkways | LOW | ROUTINE | Detailing | 30-JUN | NO | Erection Manual task |
| E-011 | Safety Railings | LOW | ROUTINE | Detailing | 30-JUN | NO | Standard specification |
| E-012 | Roof Drainage | LOW | ROUTINE | Arch/MEP | 30-JUN | NO | Outside PEB scope |
| E-013 | Bracing Design | MEDIUM | INCOMPLETE | Detailing | 30-JUN | NO | Assigned to detail phase |
| E-014 | Nameplate | LOW | ROUTINE | PM | 1-JUL | NO | Admin closeout task |
| E-015 | As-Built Resp | LOW | ROUTINE | PM | 1-JUL | NO | Contract clarification |

---

## EXCEPTION LOG VALIDATION CONCLUSION

**Validation Result:** ✓ **ALL EXCEPTIONS REVIEWED & ASSESSED**

- **Total Exceptions:** 15
- **Blocking Exceptions:** 0
- **Non-Blocking Exceptions:** 15 (100%)
- **Detailing Authorization Impact:** ✓ NONE (authorized to proceed)
- **Fabrication Authorization Impact:** Conditional (pending E-001, E-003, E-004 resolution)

**Recommendation:** **PROCEED WITH DETAILING IMMEDIATELY**

All exceptions have clear resolution paths. No exceptions block detailing phase initiation. Continue exception tracking & resolution on established timeline.

---

**Report Classification:** DESIGN AUTHORITY BASELINE  
**Date:** 6-MAY-2026  
**Next Review:** 15-JUN-2026 (pre-fabrication release gate)
