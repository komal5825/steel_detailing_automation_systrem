# GA_BLOCKING_EXCEPTION_LIST
## C163-027 Saswad Industrial Shed & Crane Building

**Report Date:** 6-MAY-2026  
**Total Exceptions Reviewed:** 7  
**GA-Blocking Exceptions:** 0  
**Result:** ✓ **NO BLOCKING EXCEPTIONS IDENTIFIED**

---

## EXECUTIVE SUMMARY

Comprehensive review of all 7 open exceptions confirms **zero exceptions block GA grid or frame production**. 5 exceptions affect foundation interface (outside GA scope); 2 exceptions are conditional/non-critical.

| Category | Count | Blocking GA | Status |
|----------|-------|---|---|
| **Total Exceptions** | 7 | 0 | ✓ NONE BLOCK GA |
| Blocks GA Grid | 0 | - | - |
| Blocks GA Frame | 0 | - | - |
| Blocks GA Foundation | 5 | NO (out of scope) | Non-blocking |
| Conditional (low severity) | 2 | NO | Non-blocking |

---

## BLOCKING EXCEPTION SEARCH RESULTS

**Search Criteria:** Exceptions where Blocks_GA_Grid = 'YES' OR Blocks_GA_Frame = 'YES'

**Result:** No exceptions matching criteria

### Detailed Blocking Rule Assessment

| Rule | Condition | Result | Impact |
|------|-----------|--------|--------|
| **Rule 1** | Grid geometry missing | NOT TRIGGERED | Grid complete (9/9 lines) |
| **Rule 2** | Primary frame mapping incomplete | NOT TRIGGERED | All members mapped (6/6) |
| **Rule 3** | Unresolved openings affecting layout | NOT TRIGGERED | No openings (0 total) |
| **Rule 4** | Anchor bolts incomplete (if in scope) | N/A | Excluded from GA scope |
| **Rule 5** | GA_Seed missing | NOT TRIGGERED | Seed available & populated |

---

## COMPLETE EXCEPTION INVENTORY

### Exceptions Not Blocking GA (7 total)

| Exc_ID | Title | Severity | Blocks_GA_Grid | Blocks_GA_Frame | Blocks_GA_Foundation | Status | Impact on GA |
|--------|-------|----------|---|---|---|---|---|
| **E-001** | Base Elevation (GL+0.6m) not confirmed | MEDIUM | NO | NO | YES | OPEN | **NOT BLOCKING** (foundation out of GA scope) |
| **E-002** | Foundation design out of scope | HIGH | NO | NO | YES | BY_DESIGN | **NOT BLOCKING** (acknowledged scope) |
| **E-003** | Soil bearing capacity not verified | HIGH | NO | NO | YES | OPEN | **NOT BLOCKING** (geotechnical, not GA) |
| **E-004** | Crane hoist tonnage not confirmed | MEDIUM | NO | NO | NO | OPEN | **NOT BLOCKING** (status N/A) |
| **E-006** | Mezzanine connections preliminary | LOW | NO | NO | NO | OPEN | **NOT BLOCKING** (not applicable) |
| **E-012** | Anchor bolt procedure TBD | MEDIUM | NO | NO | YES | OPEN | **NOT BLOCKING** (detail phase; excluded from GA) |
| **E-014** | Base plate gusset moment TBD | MEDIUM | NO | NO | YES | OPEN | **NOT BLOCKING** (detail phase; excluded from GA) |

---

## EXCEPTION CLASSIFICATION BY IMPACT

### Foundation Interface Exceptions (5 total - Out of GA Scope)

| Exc_ID | Title | GA Impact | Notes |
|--------|-------|-----------|-------|
| E-001 | Base Elevation not confirmed | **NOT BLOCKING** | Affects anchor bolt length; excluded from GA scope |
| E-002 | Foundation out of scope | **NOT BLOCKING** | Acknowledged; separate project phase |
| E-003 | Soil bearing not verified | **NOT BLOCKING** | Geotechnical input; affects foundation design, not GA |
| E-012 | Anchor bolt procedure TBD | **NOT BLOCKING** | Detail phase; Anchor Bolt Plan separate from GA |
| E-014 | Base plate gusset TBD | **NOT BLOCKING** | Connection detail; not GA content |

**Scope Exclusion:** All foundation interface items (base elevation, anchor bolt layout, foundation design) are explicitly excluded from GA scope. These are produced separately in:
- Anchor Bolt Plan (E-012)
- Base Connection Details (E-014)
- Foundation Design (E-002, E-003 - separate consultant)

**Result:** Zero GA-blocking issues from foundation interface exceptions.

---

### Conditional/Non-Critical Exceptions (2 total)

| Exc_ID | Title | GA Impact | Notes |
|--------|-------|-----------|-------|
| E-004 | Crane tonnage not confirmed | **NOT BLOCKING** | Status = NOT_APPLICABLE (no crane system); building designed without internal crane |
| E-006 | Mezzanine preliminary | **NOT BLOCKING** | Status = NOT_APPLICABLE (no mezzanine); building is single-story |

**Assessment:** Both exceptions are low-impact because subject items (crane, mezzanine) are not part of baseline design. If crane/mezzanine added later, would require separate design phase (not impact current GA).

**Result:** Zero GA-blocking issues from conditional exceptions.

---

## BLOCKING RULE VERIFICATION MATRIX

| Blocking Rule | GA_Grid Impact | GA_Frame Impact | Status | Triggering |
|---|---|---|---|---|
| **Rule 1:** Grid geometry missing | CRITICAL | N/A | Grid complete (9/9) | NOT TRIGGERED |
| **Rule 2:** Primary frame mapping incomplete | N/A | CRITICAL | Mapping complete (6/6) | NOT TRIGGERED |
| **Rule 3:** Unresolved openings affecting layout | MEDIUM | MEDIUM | No openings (0 total) | NOT TRIGGERED |
| **Rule 4:** Anchor bolts incomplete (if in scope) | N/A | N/A | Excluded from GA | N/A (Rule conditional) |
| **Rule 5:** GA_Seed missing | CRITICAL | CRITICAL | Seed available | NOT TRIGGERED |

**Conclusion:** All blocking rules satisfied. **NO BLOCKING CONDITIONS TRIGGERED.**

---

## EXCEPTION RESOLUTION TIMELINE

### Exceptions Not Critical for GA (Non-Blocking)

| Exc_ID | Title | Timeline | Owner | Impact on GA |
|--------|-------|----------|-------|---|
| E-001 | Base Elevation | BEFORE_DETAILING | Client/Site | None (after GA produced) |
| E-002 | Foundation scope | SEPARATE_PHASE | Project Mgmt | None (acknowledged) |
| E-003 | Soil bearing | BEFORE_FOUNDATION | Geotechnical | None (geotechnical task) |
| E-004 | Crane tonnage | BEFORE_DETAILING | Client | None (N/A to current design) |
| E-006 | Mezzanine | PHASE-2 | Design | None (not applicable) |
| E-012 | Bolt procedure | DURING_DETAILING | Detailing | None (excluded from GA) |
| E-014 | Gusset design | DURING_DETAILING | Detailing | None (excluded from GA) |

**All exceptions resolve AFTER GA baseline produced → Zero schedule impact on GA.**

---

## SCOPE CLARIFICATION: What GA Does & Does Not Include

### GA Includes (Grid & Frame Focus)

✓ Building floor plan (grid, column locations)  
✓ Building roof plan (purlin/girt layout)  
✓ Elevation views (frame profiles, slopes)  
✓ Section details (roof ridge, eave connection)  
✓ Primary frame members (columns, rafters)  
✓ Secondary member layout (purlin/girt spacing)  
✓ Bracing system layout  
✓ Endwall configuration  

### GA Does NOT Include (Separate Drawings)

✗ Foundation footings (foundation design - separate)  
✗ Anchor bolt detail layout (Anchor Bolt Plan - separate)  
✗ Base plate connection design (Connection Details - separate)  
✗ Member dimensions/sizing (covered in Member Schedules)  
✗ Detailed connection patterns (Connection Details - separate)  

**Exception Impact:** Since foundation interface items (E-001, E-002, E-003, E-012, E-014) are outside GA scope, they do not block GA production.

---

## FINAL DETERMINATION

**GA Blocking Exception Search Result:** ✓ **NO BLOCKING EXCEPTIONS FOUND**

| Criteria | Result |
|----------|--------|
| Grid blocking exceptions | 0 |
| Frame blocking exceptions | 0 |
| Blocking rules triggered | 0 |
| Blocking conditions identified | 0 |
| **GA Production Authorized** | ✓ **YES** |

---

## RECOMMENDED ACTION

### For GA Detailing Team

**Proceed with GA Production.** No exceptions block grid or frame production. All required design data available.

### For Design Authority

**Monitor Non-Blocking Exceptions:**
- E-001 (base elevation) → resolve before 10-JUN
- E-003 (soil bearing) → resolve before 10-JUN
- E-012, E-014 (detail items) → resolve during detailing phase

**Non-blocking status does not mean non-critical.** These exceptions affect downstream detailing; track closure to maintain schedule.

---

**Report Classification:** DESIGN AUTHORITY BASELINE  
**Date:** 6-MAY-2026
