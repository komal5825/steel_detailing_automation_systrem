# GA_CONDITIONAL_EXCEPTION_LIST
## C163-027 Saswad Industrial Shed & Crane Building

**Report Date:** 6-MAY-2026  
**Total Exceptions Reviewed:** 7  
**Conditional (Non-Blocking) Exceptions:** 7  
**Result:** ✓ **ALL EXCEPTIONS CONDITIONAL - NO BLOCKERS**

---

## EXECUTIVE SUMMARY

All 7 open exceptions are **conditional (non-blocking) for GA production**. 5 exceptions affect foundation interface (outside GA scope); 2 exceptions are low-criticality (N/A to current design). None prevent GA grid or frame production.

| Exception Type | Count | Blocking GA | Status |
|---|---|---|---|
| **Foundation Interface (Out of GA Scope)** | 5 | NO | Excluded from GA |
| **Conditional/Low-Severity (N/A)** | 2 | NO | Not applicable |
| **Blocking GA Grid/Frame** | 0 | - | None |
| **TOTAL** | **7** | **0** | ✓ **NONE BLOCK** |

---

## CONDITIONAL EXCEPTION DETAILED LOG

### Exception Group 1: Foundation Interface (Out of GA Scope)

These exceptions affect foundation design or anchor bolt layout, both explicitly excluded from GA scope. GA can proceed; these resolved in parallel phases.

---

#### **E-001: Base Elevation (GL+0.6m) Not Confirmed**

**Severity:** MEDIUM  
**Category:** Assumption (Site/Client Input)  
**Status:** OPEN  
**Owner:** Client / Site Survey  
**Timeline:** BEFORE_DETAILING  

| Field | Value |
|-------|-------|
| **Blocking GA Grid** | NO |
| **Blocking GA Frame** | NO |
| **Blocking GA Foundation** | YES (but out of scope) |
| **Conditional for GA** | **YES** |
| **Impact on GA Content** | None (foundation excluded) |

**Issue Description:**
Building base elevation (finished floor level) not confirmed by client site. Affects anchor bolt length calculation and foundation footing design. Current assumption: GL+0.6m (provisional).

**Why Not Blocking GA:**
- GA scope = building grid, frame layout, member positioning (above-ground structure)
- Foundation design = separate phase (geotechnical + structural foundation)
- Base elevation affects foundation, not GA frame
- GA can show base plate locations symbolically (detailed anchor bolt positions in Anchor Bolt Plan, after elevation confirmed)

**GA Production Approach:**
1. Produce GA with provisional base elevation (GL+0.6m)
2. Show base plate symbols at estimated column base locations
3. Note in GA remarks: "Base elevation TBD (E-001); anchor bolt detail in separate Anchor Bolt Plan"
4. Update Anchor Bolt Plan once elevation confirmed (by 10-JUN)

**Resolution Required Before:**
- Anchor Bolt Plan detailed drawing (10-JUN)
- Fabrication release (15-JUN)

**Conditional Status:** **YES** - Resolved after GA baseline; non-blocking for GA start

---

#### **E-002: Foundation Design Out of Scope**

**Severity:** HIGH  
**Category:** Scope Exclusion  
**Status:** OPEN (BY_DESIGN)  
**Owner:** Project Manager / Separate Consultant  
**Timeline:** SEPARATE_PHASE  

| Field | Value |
|-------|-------|
| **Blocking GA Grid** | NO |
| **Blocking GA Frame** | NO |
| **Blocking GA Foundation** | YES (but acknowledged) |
| **Conditional for GA** | **YES** (by design) |
| **Impact on GA Content** | None (PEB scope only) |

**Issue Description:**
Foundation structural design (footings, piles, pedestal) is outside scope of PEB structural contract. Will be performed by separate geotechnical/structural consultant. Interface coordination required (base plate elevations, anchor bolt reactions).

**Why Not Blocking GA:**
- GA scope = PEB superstructure (columns, rafters, secondary members)
- Foundation design = separate contracted scope
- Acknowledged limitation; planned as parallel work
- PEB provides interface data (base plate elevations, reactions) to foundation engineer

**GA Production Approach:**
1. GA shows base plate symbols and reactions (from PEB design)
2. Foundation interface drawing prepared separately
3. No detailed footing design in GA (separate scope)
4. Coordinate interface drawing with foundation engineer (parallel work)

**Resolution Required Before:**
- Building construction (foundation phase before PEB erection)
- Not critical for GA or PEB detailing

**Conditional Status:** **YES** (by design) - Known scope boundary; managed separately

---

#### **E-003: Soil Bearing Capacity Not Verified**

**Severity:** HIGH  
**Category:** External Input (Geotechnical)  
**Status:** OPEN  
**Owner:** Geotechnical Consultant  
**Timeline:** BEFORE_FOUNDATION  

| Field | Value |
|-------|-------|
| **Blocking GA Grid** | NO |
| **Blocking GA Frame** | NO |
| **Blocking GA Foundation** | YES (but out of scope) |
| **Conditional for GA** | **YES** |
| **Impact on GA Content** | None (geotechnical task) |

**Issue Description:**
Soil bearing capacity and settlement analysis not yet verified by site geotechnical survey. Affects foundation footing design (size, depth, type). Required before foundation construction but not GA production.

**Why Not Blocking GA:**
- GA scope = superstructure (PEB frame)
- Soil bearing = geotechnical investigation scope
- GA assumes base elevations; footing design secondary
- PEB provides anchor bolt reactions to foundation engineer (they design footings)

**GA Production Approach:**
1. GA uses provisional base elevation (GL+0.6m)
2. Shows anchor bolt reactions on base plate (calculated per PEB design)
3. Separate Geotechnical Report will provide soil data & footing design recommendations
4. No geotechnical content in GA

**Resolution Required Before:**
- Foundation footing design (geotechnical phase)
- Not critical for GA; critical for foundation construction

**Conditional Status:** **YES** - Geotechnical investigation parallel to GA/detailing; results incorporated after GA

---

#### **E-012: Anchor Bolt Tensioning Procedure TBD**

**Severity:** MEDIUM  
**Category:** Detail Specification (QC/Installation)  
**Status:** OPEN  
**Timeline:** DURING_DETAILING  

| Field | Value |
|-------|-------|
| **Blocking GA Grid** | NO |
| **Blocking GA Frame** | NO |
| **Blocking GA Foundation** | YES (but detail phase) |
| **Conditional for GA** | **YES** |
| **Impact on GA Content** | None (excluded from GA) |

**Issue Description:**
Anchor bolt tensioning procedure (torque values, sequence, QC method) not yet specified. To be detailed during detailing phase (after Anchor Bolt Plan design).

**Why Not Blocking GA:**
- GA scope = member layout, positioning
- Tensioning procedure = installation phase detail (Erection Manual scope)
- GA does not show bolt tensioning data
- Detail to be produced separately in Anchor Bolt Plan & Erection Manual

**GA Production Approach:**
1. GA shows anchor bolt locations (symbolic callouts)
2. Detailed bolt specification (grade, size, torque) in Anchor Bolt Plan
3. Tensioning procedure in Erection Manual & Fabrication Specs
4. No tensioning detail required for GA

**Resolution Required Before:**
- Erection Manual (30-JUN)
- Not critical for GA

**Conditional Status:** **YES** - Detail phase item; excluded from GA scope

---

#### **E-014: Base Plate Gusset Moment Capacity TBD**

**Severity:** MEDIUM  
**Category:** Detail Specification (Connection)  
**Status:** OPEN  
**Timeline:** DURING_DETAILING  

| Field | Value |
|-------|-------|
| **Blocking GA Grid** | NO |
| **Blocking GA Frame** | NO |
| **Blocking GA Foundation** | YES (but detail phase) |
| **Conditional for GA** | **YES** |
| **Impact on GA Content** | None (excluded from GA) |

**Issue Description:**
Base plate gusset stiffening detail and moment capacity not yet finalized. To be designed during detailing phase as part of connection design (separate from GA).

**Why Not Blocking GA:**
- GA scope = building layout, member positions
- Gusset design = connection detail (Connection Details drawing)
- GA shows base plate location only; not internal detail
- Gusset detail excluded from GA scope (included in Base Connection Details)

**GA Production Approach:**
1. GA shows base plate as symbol/callout
2. Gusset design detail produced in Connection Details drawing
3. No internal base plate detail required for GA
4. GA references "See Connection Details" for base plate specification

**Resolution Required Before:**
- Connection Details drawing (15-JUN)
- Fabrication release (15-JUN)

**Conditional Status:** **YES** - Connection detail phase item; excluded from GA scope

---

### Exception Group 2: Conditional / Low-Severity (N/A to Current Design)

These exceptions are low-severity and non-applicable to current GA scope. No impact on GA production.

---

#### **E-004: Crane Hoist Tonnage Not Confirmed**

**Severity:** MEDIUM  
**Category:** Equipment Specification  
**Status:** OPEN  
**Timeline:** BEFORE_DETAILING  

| Field | Value |
|-------|-------|
| **Blocking GA Grid** | NO |
| **Blocking GA Frame** | NO |
| **Blocking GA Foundation** | NO |
| **Conditional for GA** | **YES** (low priority) |
| **Impact on GA Content** | None (N/A) |

**Issue Description:**
Crane hoist system tonnage capacity not confirmed by client. If >2T, may require additional bracing. Current design conservatively assumes ≤2T (or no crane).

**Why Not Blocking GA:**
- GA scope = building frame layout
- Crane status = NOT_APPLICABLE (per GA_Seed)
- Design assumes no crane system (no impact on GA)
- If crane added later, would require design review (not GA revision)

**GA Production Approach:**
1. GA produced without internal crane provisions
2. If client later confirms crane system needed, separate design phase required
3. Current GA scope = simple industrial shed frame

**Resolution Required Before:**
- Design decision on crane system (before end of detailing phase)
- Not critical for current GA

**Conditional Status:** **YES** (low-priority) - Not applicable to current design

---

#### **E-006: Mezzanine Connections Preliminary Only**

**Severity:** LOW  
**Category:** Equipment/Structural  
**Status:** OPEN  
**Timeline:** PHASE-2  

| Field | Value |
|-------|-------|
| **Blocking GA Grid** | NO |
| **Blocking GA Frame** | NO |
| **Blocking GA Foundation** | NO |
| **Conditional for GA** | **YES** (low priority) |
| **Impact on GA Content** | None (N/A) |

**Issue Description:**
Mezzanine / intermediate platform connections preliminary only. May be revised in future phases if mezzanine added.

**Why Not Blocking GA:**
- GA scope = primary building frame
- Mezzanine status = NOT_APPLICABLE (per GA_Seed)
- Design assumes single-story building (no mezzanine)
- If mezzanine added later, separate design phase required

**GA Production Approach:**
1. GA produced for single-story building only
2. No mezzanine structural provisions shown
3. If mezzanine required later, separate design & detailing phase

**Resolution Required Before:**
- Project decision on mezzanine (if any)
- Not critical for current GA

**Conditional Status:** **YES** (low-priority) - Not applicable to current design

---

## CONDITIONAL EXCEPTION RESOLUTION TIMELINE

### Exceptions Resolved Before GA Baseline (Non-Impact)

| Exc_ID | Title | Timeline | Owner | GA Impact |
|--------|-------|----------|-------|-----------|
| (none - all resolved after GA) | - | - | - | - |

**Result:** All exceptions are resolved after GA baseline produced. Zero impact on GA schedule.

### Exceptions Resolved During/After Detailing (Non-Impact on GA)

| Exc_ID | Title | Resolve By | Owner | GA Status |
|--------|-------|-----------|-------|-----------|
| E-001 | Base Elevation | 10-JUN | Client | Not blocking (foundation out of scope) |
| E-002 | Foundation Scope | PHASE-2 | PM | Not blocking (acknowledged) |
| E-003 | Soil Bearing | 10-JUN | Geotech | Not blocking (geotechnical task) |
| E-004 | Crane Tonnage | End Detailing | Client | Not blocking (N/A) |
| E-006 | Mezzanine | PHASE-2 | Design | Not blocking (N/A) |
| E-012 | Bolt Procedure | 30-JUN | Detailing | Not blocking (Erection Manual) |
| E-014 | Gusset Design | 15-JUN | Detailing | Not blocking (Connection Details) |

**All exceptions resolved after GA baseline → Zero schedule impact on GA start.**

---

## SCOPE BOUNDARIES CLARIFICATION

### GA Includes (Delivered in GA Drawing)

✓ Building floor plan with grid  
✓ Roof plan with purlin layout  
✓ Elevation views (primary frame profile)  
✓ Section details (roof ridge to base)  
✓ Bracing system layout  
✓ Endwall configuration  
✓ Secondary member spacing  
✓ Base plate locations (symbolic)  

### GA Excludes (Separate Deliverables)

✗ Foundation design (separate scope)  
✗ Detailed anchor bolt layout (Anchor Bolt Plan)  
✗ Base plate gusset detail (Connection Details)  
✗ Bolt tensioning procedure (Erection Manual)  
✗ Crane system provisions (if not in current design)  
✗ Mezzanine structure (if not in current design)  
✗ Detailed member dimensions (Member Schedules)  

**Implication:** All conditional exceptions fall within GA-excluded scope. Therefore, zero blocking impact.

---

## CONDITIONAL EXCEPTION MANAGEMENT STRATEGY

### For GA Production Team

**Action:** Proceed with GA immediately. All exceptions are conditional/non-blocking.

**Data Dependencies:**
- ✓ Grid geometry available (locked)
- ✓ Frame layout available (frozen)
- ✓ Building dimensions available (confirmed)
- ✓ Member references available (mapped)
- ⚠ Member coordinates TBD (E-COBJ-001; use provisional from Grid_Geometry)
- ⚠ Member sections TBD (E-COBJ-002; extract from Handoff schedules)

### For Design Authority

**Action:** Monitor conditional exceptions; track for resolution timeline.

**Priority:** All conditional exceptions are non-critical for GA. Monitor for detailing impact:
- E-001, E-003: Resolve before Anchor Bolt Plan (10-JUN)
- E-012, E-014: Resolve during detailing (by 15-30 JUN)
- E-004, E-006: Low-priority; non-applicable to current design

### For Detailing Coordinator

**Action:** Use conditional exception status to manage downstream workflows.

**Schedule Impact:** None (all exceptions excluded from GA or resolved after GA)

---

## FINAL DETERMINATION

**Conditional Exception Assessment Result:** ✓ **ALL EXCEPTIONS CONDITIONAL - NON-BLOCKING**

| Criterion | Result |
|-----------|--------|
| Exceptions blocking GA grid | 0 |
| Exceptions blocking GA frame | 0 |
| Exceptions blocking GA production start | 0 |
| All exceptions conditional or N/A | YES |
| **GA Authorization** | ✓ **APPROVED** |

---

## RECOMMENDED ACTION

### Immediate (Now)

**Authorize GA production to commence 1-JUN-2026.** No blocking exceptions. All conditional exceptions resolved after GA baseline.

### Parallel Work (During GA Production)

1. **Correct primary member coordinates** (E-COBJ-001) - URGENT
2. **Correct primary member sections** (E-COBJ-002) - URGENT
3. Monitor conditional exception status (weekly updates)
4. Coordinate with foundation consultant (E-002, E-003)

### Sequential Work (After GA Baseline)

1. **Resolve E-001** (base elevation) by 10-JUN → Input to Anchor Bolt Plan
2. **Resolve E-012, E-014** during detailing → Connection Details, Erection Manual
3. **Monitor E-004, E-006** for any design changes (low-priority)

---

**Report Classification:** DESIGN AUTHORITY BASELINE  
**Date:** 6-MAY-2026
